"""
Ядро проекта: модель Блэка — Шоулза (геометрическое броуновское движение)
и оценка стоимости европейского опциона методом Монте-Карло.

Модель рынка (риск-нейтральная мера):
    dS = r * S dt + sigma * S dW
Точное решение:
    S_T = S0 * exp((r - sigma^2 / 2) * T + sigma * sqrt(T) * Z),   Z ~ N(0, 1)
Цена колл-опциона:
    C = exp(-r T) * E[max(S_T - K, 0)]
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Tuple

import numpy as np


def norm_cdf(x: float) -> float:
    """Функция распределения стандартного нормального закона N(0, 1)."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


@dataclass(frozen=True)
class Params:
    """Параметры модели рынка и опциона."""

    S0: float = 100.0     # начальная цена акции
    K: float = 100.0      # цена исполнения (страйк)
    T: float = 1.0        # срок до исполнения, лет
    r: float = 0.05       # безрисковая ставка (в год)
    sigma: float = 0.20   # волатильность (в год)

    def __post_init__(self) -> None:
        if self.S0 <= 0 or self.K <= 0:
            raise ValueError("S0 и K должны быть положительными")
        if self.T <= 0:
            raise ValueError("T должно быть положительным")
        if self.sigma <= 0:
            raise ValueError("sigma должна быть положительной")


# --------------------------------------------------------------------------
# Точное решение (эталон)
# --------------------------------------------------------------------------
def _d1_d2(p: Params) -> Tuple[float, float]:
    d1 = (math.log(p.S0 / p.K) + (p.r + 0.5 * p.sigma ** 2) * p.T) / (p.sigma * math.sqrt(p.T))
    d2 = d1 - p.sigma * math.sqrt(p.T)
    return d1, d2


def black_scholes_call(p: Params) -> float:
    """Точная цена европейского колл-опциона по формуле Блэка — Шоулза."""
    d1, d2 = _d1_d2(p)
    return p.S0 * norm_cdf(d1) - p.K * math.exp(-p.r * p.T) * norm_cdf(d2)


def black_scholes_put(p: Params) -> float:
    """Точная цена европейского пут-опциона по формуле Блэка — Шоулза."""
    d1, d2 = _d1_d2(p)
    return p.K * math.exp(-p.r * p.T) * norm_cdf(-d2) - p.S0 * norm_cdf(-d1)


def discounted_payoff_std(p: Params) -> float:
    """
    Точное стандартное отклонение дисконтированной выплаты колл-опциона.

    Нужно для теории: стандартная ошибка Монте-Карло = std / sqrt(N).
    Используем E[(S_T-K)^2 * 1{S_T>K}] = E[S^2 1] - 2K E[S 1] + K^2 P(S>K).
    """
    d1, d2 = _d1_d2(p)
    s = p.sigma * math.sqrt(p.T)
    e_s2 = p.S0 ** 2 * math.exp((2 * p.r + p.sigma ** 2) * p.T) * norm_cdf(d1 + s)
    e_s = p.S0 * math.exp(p.r * p.T) * norm_cdf(d1)
    second_moment = e_s2 - 2 * p.K * e_s + p.K ** 2 * norm_cdf(d2)
    disc = math.exp(-p.r * p.T)
    variance = disc ** 2 * second_moment - black_scholes_call(p) ** 2
    return math.sqrt(max(variance, 0.0))


# --------------------------------------------------------------------------
# Монте-Карло
# --------------------------------------------------------------------------
def terminal_prices(p: Params, z: np.ndarray) -> np.ndarray:
    """Цены акции в момент T по стандартным нормальным числам z."""
    drift = (p.r - 0.5 * p.sigma ** 2) * p.T
    return p.S0 * np.exp(drift + p.sigma * math.sqrt(p.T) * z)


def _mc(p: Params, n: int, rng: np.random.Generator, antithetic: bool, kind: str) -> Tuple[float, float]:
    if n < 2:
        raise ValueError("n должно быть >= 2")
    disc = math.exp(-p.r * p.T)

    def payoff(s: np.ndarray) -> np.ndarray:
        return np.maximum(s - p.K, 0.0) if kind == "call" else np.maximum(p.K - s, 0.0)

    if antithetic:
        half = n // 2
        z = rng.standard_normal(half)
        # пары (Z, -Z): усредняем выплаты внутри пары, получаем half независимых величин
        values = disc * 0.5 * (payoff(terminal_prices(p, z)) + payoff(terminal_prices(p, -z)))
    else:
        z = rng.standard_normal(n)
        values = disc * payoff(terminal_prices(p, z))

    m = values.size
    estimate = float(values.mean())
    std_error = float(values.std(ddof=1) / math.sqrt(m))
    return estimate, std_error


def mc_call(p: Params, n: int, rng: np.random.Generator, antithetic: bool = False) -> Tuple[float, float]:
    """
    Оценка цены колл-опциона методом Монте-Карло.

    Возвращает (оценка, стандартная ошибка).
    n — число симуляций (при antithetic=True — число выплат; нормальных чисел потребуется n/2).
    """
    return _mc(p, n, rng, antithetic, "call")


def mc_put(p: Params, n: int, rng: np.random.Generator, antithetic: bool = False) -> Tuple[float, float]:
    """Оценка цены пут-опциона методом Монте-Карло: (оценка, стандартная ошибка)."""
    return _mc(p, n, rng, antithetic, "put")


def simulate_paths(p: Params, n_paths: int, n_steps: int, rng: np.random.Generator) -> np.ndarray:
    """
    Траектории геометрического броуновского движения (для иллюстраций).

    Возвращает массив формы (n_paths, n_steps + 1); столбец 0 — начальная цена.
    Используется точная схема (без ошибки дискретизации).
    """
    dt = p.T / n_steps
    z = rng.standard_normal((n_paths, n_steps))
    log_increments = (p.r - 0.5 * p.sigma ** 2) * dt + p.sigma * math.sqrt(dt) * z
    log_paths = np.concatenate([np.zeros((n_paths, 1)), np.cumsum(log_increments, axis=1)], axis=1)
    return p.S0 * np.exp(log_paths)
