"""Тесты ядра. Запуск: `python -m pytest` или `python tests/test_pricing.py`."""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from mcoptions import (  # noqa: E402
    Params,
    black_scholes_call,
    black_scholes_put,
    discounted_payoff_std,
    mc_call,
    mc_put,
    simulate_paths,
)


def test_black_scholes_reference_value():
    # Классический эталон: S0=K=100, T=1, r=5%, sigma=20% -> 10.4506
    assert abs(black_scholes_call(Params()) - 10.4506) < 1e-4


def test_put_call_parity():
    # C - P = S0 - K * exp(-rT)
    for p in [Params(), Params(K=80), Params(K=130, sigma=0.4), Params(T=0.25, r=0.01)]:
        lhs = black_scholes_call(p) - black_scholes_put(p)
        rhs = p.S0 - p.K * math.exp(-p.r * p.T)
        assert abs(lhs - rhs) < 1e-10


def test_mc_converges_within_five_standard_errors():
    p = Params()
    rng = np.random.default_rng(1)
    est, se = mc_call(p, 200_000, rng)
    assert abs(est - black_scholes_call(p)) < 5 * se


def test_mc_put_converges():
    p = Params()
    rng = np.random.default_rng(2)
    est, se = mc_put(p, 200_000, rng)
    assert abs(est - black_scholes_put(p)) < 5 * se


def test_antithetic_has_smaller_error_estimate():
    p = Params()
    _, se_plain = mc_call(p, 100_000, np.random.default_rng(3))
    _, se_anti = mc_call(p, 100_000, np.random.default_rng(3), antithetic=True)
    assert se_anti < se_plain


def test_theoretical_payoff_std_matches_simulation():
    p = Params()
    rng = np.random.default_rng(4)
    z = rng.standard_normal(2_000_000)
    s = p.S0 * np.exp((p.r - 0.5 * p.sigma ** 2) * p.T + p.sigma * math.sqrt(p.T) * z)
    sample_std = (math.exp(-p.r * p.T) * np.maximum(s - p.K, 0)).std(ddof=1)
    assert abs(sample_std - discounted_payoff_std(p)) / sample_std < 0.01


def test_paths_shape_and_start():
    paths = simulate_paths(Params(), 5, 50, np.random.default_rng(5))
    assert paths.shape == (5, 51)
    assert np.all(paths[:, 0] == 100.0)
    assert np.all(paths > 0)


def test_invalid_params_raise():
    for kwargs in [dict(S0=-1), dict(K=0), dict(T=0), dict(sigma=-0.1)]:
        try:
            Params(**kwargs)
        except ValueError:
            continue
        raise AssertionError(f"ожидалась ошибка для {kwargs}")


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print("OK ", t.__name__)
    print(f"Все тесты пройдены: {len(tests)}")
